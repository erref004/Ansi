<div class="flex gap-2 item-center text-center justify-center">
    <img src="/assets/img/logo-al-fitroh.jpg" alt="logo">
    <div class="fi-logo flex text-xl font-bold  tracking-tight text-gray-950 dark:text-white">
        {{ config('app.name') }}
    </div>
</div>
