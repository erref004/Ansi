<?php

namespace App\Filament\Resources\PengunjungResource\Pages;

use App\Filament\Resources\PengunjungResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePengunjung extends CreateRecord
{
    protected static string $resource = PengunjungResource::class;
}
