<?php

namespace App\Filament\Resources\AnakAsuhResource\Pages;

use App\Filament\Resources\AnakAsuhResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAnakAsuh extends CreateRecord
{
    protected static string $resource = AnakAsuhResource::class;
}
